//
//  ViewController.swift
//  Notification Test
//
//  Created by AMT on 9/10/18.
//  Copyright © 2018 Amt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var deviceTokenLbl: UILabel!
    @IBOutlet weak var copyButton: UIButton!
    
    let appDelegate: AppDelegate? = UIApplication.shared.delegate as? AppDelegate

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        if appDelegate?.device_token == nil {
//            UIApplication.shared.registerForRemoteNotifications()
//        }else{
//
//            self.deviceTokenLbl.text! = (appDelegate?.device_token)!
//
//        }
        
        if UserDefaults.standard.value(forKey: "devicetoken") as? String == nil{
            UIApplication.shared.registerForRemoteNotifications()
            return
        }else{
                let deviceToken = UserDefaults.standard.value(forKey: "devicetoken") as? String
                if deviceToken != nil{
                   self.deviceTokenLbl.text! = deviceToken!
                }
             }
        
        
            }
    
    @IBAction func copyButtonAction(_ sender: Any) {
        let pasteboard = UIPasteboard.general
            pasteboard.string = deviceTokenLbl.text!
    }
}

