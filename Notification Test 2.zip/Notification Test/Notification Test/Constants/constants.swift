//
//  constants.swift
//  Notification Test
//
//  Created by AMT on 9/10/18.
//  Copyright © 2018 Amt. All rights reserved.
//

import Foundation

class constants{
    
    class func getValueFromUserDefults(for key:String) -> Any?{
        let userDefault = UserDefaults.standard
        return userDefault.value(forKey: key)
    }
    class func setValueInUserDefaults(objValue:String,for key:String){
        let userDefault = UserDefaults.standard
        userDefault.set(objValue, forKey: key)
        userDefault.synchronize()
    }
}
